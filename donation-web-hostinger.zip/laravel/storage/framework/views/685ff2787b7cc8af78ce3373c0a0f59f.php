<?php $__env->startSection('content'); ?>
<section class="max-w-7xl mx-auto px-6 py-20">
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        <!-- Sidebar Menu -->
        <div class="lg:col-span-1 space-y-6">
            <?php echo $__env->make('admin.sidebar', ['active' => 'users'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <!-- Dashboard Content -->
        <div class="lg:col-span-3 space-y-8">
            <div class="space-y-2">
                <h1 class="text-2xl sm:text-3xl font-montserrat font-black text-slate-900 uppercase tracking-tight italic">
                    Kelola <span class="text-primary-600">Pengguna & Hak Akses</span>
                </h1>
                <div class="w-12 h-1 bg-primary-500 rounded-full"></div>
            </div>

            <!-- Users table -->
            <div class="bg-white border border-slate-100 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="border-b border-slate-100 text-[10px] font-black uppercase tracking-wider text-slate-400">
                                <th class="pb-4">Nama</th>
                                <th class="pb-4">Email</th>
                                <th class="pb-4">Peran / Hak Akses</th>
                                <th class="pb-4">No. Telp</th>
                                <th class="pb-4">Terdaftar</th>
                                <th class="pb-4 text-right">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="text-xs font-semibold text-slate-600 uppercase tracking-wide">
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-b border-slate-50 last:border-0">
                                    <td class="py-4"><?php echo e($user->name); ?></td>
                                    <td class="py-4"><?php echo e($user->email); ?></td>
                                    <td class="py-4">
                                        <?php if($user->role === 'admin'): ?>
                                            <span class="bg-red-50 text-red-700 text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md">ADMIN</span>
                                        <?php elseif($user->role === 'field_worker'): ?>
                                            <span class="bg-indigo-50 text-indigo-700 text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md">PETUGAS LAPANGAN</span>
                                        <?php else: ?>
                                            <span class="bg-slate-100 text-slate-700 text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md">DONATUR</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-4"><?php echo e($user->phone ?? '-'); ?></td>
                                    <td class="py-4"><?php echo e($user->created_at->format('d M Y')); ?></td>
                                    <td class="py-4 text-right">
                                        <?php if($user->role === 'field_worker'): ?>
                                            <a href="<?php echo e(route('admin.users.monitoring', $user->id)); ?>" class="inline-flex items-center gap-1.5 px-3 py-2 bg-primary-50 text-primary-700 hover:bg-primary-100 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all border border-primary-100">
                                                <i class="fa-solid fa-gauge-high"></i> Pantau Kinerja
                                            </a>
                                        <?php else: ?>
                                            <span class="text-slate-400 font-bold">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="py-8 text-center text-slate-400 font-bold uppercase tracking-wider">Belum ada pengguna terdaftar.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div>
                    <?php echo e($users->links()); ?>

                </div>
            </div>

        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\donation-web\laravel\resources\views/admin/users.blade.php ENDPATH**/ ?>