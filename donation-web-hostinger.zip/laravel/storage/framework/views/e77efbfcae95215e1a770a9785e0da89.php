<?php $__env->startSection('content'); ?>
<section class="max-w-7xl mx-auto px-6 py-20">
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        <!-- Sidebar Menu -->
        <div class="lg:col-span-1 space-y-6">
            <?php echo $__env->make('admin.sidebar', ['active' => 'campaigns'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <!-- Dashboard Content -->
        <div class="lg:col-span-3 space-y-8">
            <div class="space-y-2">
                <h1 class="text-2xl sm:text-3xl font-montserrat font-black text-slate-900 uppercase tracking-tight italic">
                    Kelola <span class="text-primary-600">Kampanye Penggalangan Dana</span>
                </h1>
                <div class="w-12 h-1 bg-primary-500 rounded-full"></div>
            </div>

            <!-- Campaign list table -->
            <div class="bg-white border border-slate-100 rounded-3xl p-6 sm:p-8 space-y-6 shadow-sm">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="border-b border-slate-100 text-[10px] font-black uppercase tracking-wider text-slate-400">
                                <th class="pb-4">Kampanye</th>
                                <th class="pb-4">Pembuat</th>
                                <th class="pb-4">Target</th>
                                <th class="pb-4">Terkumpul</th>
                                <th class="pb-4">Status</th>
                                <th class="pb-4 text-center">Tindakan</th>
                            </tr>
                        </thead>
                        <tbody class="text-xs font-semibold text-slate-600 uppercase tracking-wide">
                            <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-b border-slate-50 last:border-0">
                                    <td class="py-4 pr-4 max-w-[200px] line-clamp-1 mt-3">
                                        <a href="<?php echo e(route('campaigns.show', $c->id)); ?>" class="hover:text-primary-600"><?php echo e($c->title); ?></a>
                                    </td>
                                    <td class="py-4"><?php echo e($c->author->name); ?></td>
                                    <td class="py-4">Rp <?php echo e(number_format($c->target_amount, 0, ',', '.')); ?></td>
                                    <td class="py-4">Rp <?php echo e(number_format($c->current_amount, 0, ',', '.')); ?></td>
                                    <td class="py-4 font-bold">
                                        <?php if($c->status === 'approved'): ?>
                                            <span class="bg-emerald-50 text-emerald-700 text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md">Approved</span>
                                        <?php elseif($c->status === 'pending'): ?>
                                            <span class="bg-amber-50 text-amber-700 text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md">Pending</span>
                                        <?php else: ?>
                                            <span class="bg-rose-50 text-rose-700 text-[8px] font-black uppercase tracking-widest px-2.5 py-1 rounded-md">Rejected</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-4 text-center">
                                        <?php if($c->status === 'pending'): ?>
                                            <div class="flex items-center justify-center gap-2">
                                                <form action="<?php echo e(route('admin.campaigns.approve', $c->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[9px] uppercase tracking-wider px-3 py-2 rounded-lg">
                                                        Setujui
                                                    </button>
                                                </form>
                                                <form action="<?php echo e(route('admin.campaigns.reject', $c->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="bg-rose-600 hover:bg-rose-700 text-white font-black text-[9px] uppercase tracking-wider px-3 py-2 rounded-lg">
                                                        Tolak
                                                    </button>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-slate-400 text-[9px] font-bold uppercase tracking-wider">Sudah Diproses</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="py-8 text-center text-slate-400 font-bold uppercase tracking-wider">Belum ada kampanye.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div>
                    <?php echo e($campaigns->links()); ?>

                </div>
            </div>

        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\donation-web\laravel\resources\views/admin/campaigns.blade.php ENDPATH**/ ?>